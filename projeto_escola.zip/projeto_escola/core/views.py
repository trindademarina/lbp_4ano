from django.http import HttpResponse
from django.shortcuts import render

# Create your views here.
def inicio(request):
    return render(request,'core/inicio.html')

def sobre (request):
    return HttpResponse("Esta pagina foi criada para apresentar o sistema e explicar um pouco sobre ele ")

