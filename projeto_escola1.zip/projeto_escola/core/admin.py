from django.contrib import admin
from .models import Livro,Aluno
admin.site.register(Livro)
admin.site.register(Aluno)

# Register your models here.
